//
//  BodyposeEstimation.swift
//  APPOSTURE
//
//  Created by Domenico De Litteris on 15/12/22.
//

import SwiftUI
import CoreML

struct BodyposeEstimation: View {
    var body: some View {
        
        let model = try VNCoreMLModel(for: MyBodyPoseEstimationModel().model)

        // Create a request to run the model on an image
        let request = VNCoreMLRequest(model: model) { request, error in
          // Handle the response here
        }

        // Run the request on the given image
        let handler = VNImageRequestHandler(cgImage: myImage)
        try handler.perform([request])

    }
}

struct BodyposeEstimation_Previews: PreviewProvider {
    static var previews: some View {
        BodyposeEstimation()
    }
}
