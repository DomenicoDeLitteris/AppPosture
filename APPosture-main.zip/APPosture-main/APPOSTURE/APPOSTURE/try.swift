//
//  try.swift
//  APPOSTURE
//
//  Created by Domenico De Litteris on 18/12/22.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var openImagePickerButton: UIButton!
    @IBOutlet weak var newButton: UIButton!

    let imagePicker = UIImagePickerController()

    override func viewDidLoad() {
        super.viewDidLoad()

        imagePicker.delegate = self
        newButton.isHidden = true
    }

    @IBAction func openImagePicker(_ sender: Any) {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        openImagePickerButton.isHidden = true
        newButton.isHidden = false
        dismiss(animated: true, completion: nil)
    }
}
