//
//  SquatInstruction.swift
//  APPOSTURE
//
//  Created by Domenico De Litteris on 17/12/22.
//

import Foundation
import SwiftUI
import PhotosUI

struct SquatInstructions: View {
    @State private var image = UIImage()
    
    @State var isSelected = false
    
    var body: some View {
        VStack {
            NavigationView {
                
                
                
                VStack(alignment: .leading) {
                    
                    ZStack {
                        Image("squat-instructions")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(30)
                            .padding(10)
                            .frame(alignment: .center)
                        
                        NavigationLink(destination: ImagePicker(sourceType: .photoLibrary, selectedImage: self.$image)) {
                            ZStack{
                                RoundedRectangle(cornerRadius: 25)
                                    .frame(width: 150,height: 55)
                                Text("Get Started")
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                
                            }
                            
                        }
                    }
                    
                    Text("Perform the squat as follows:")
                    
                        .font(.system(size: 25))
                    
                    
                    Text("1. Start standing with your feet shoulder-width apart.").font(.system(size: 20))
                    Text("2.Lower your body down as if you are sitting on a chair.").font(.system(size: 20))
                    Text("3.Keep your back straight and your buttocks back.").font(.system(size: 20))
                    Text("4. Push back up and return to the starting position.").font(.system(size: 20))
                    
                    Spacer()
                    
                }
                
                
                Spacer()
            }.navigationBarTitle("Doing a Squat")
            
            
            
                .padding()
            
            
            NavigationLink("", destination: PhotoEleaboration())
        }
    }
}



