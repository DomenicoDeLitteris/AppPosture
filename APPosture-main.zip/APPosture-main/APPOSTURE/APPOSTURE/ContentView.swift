//
//  ContentView.swift
//  APPOSTURE
//
//  Created by Domenico De Litteris on 13/12/22.
//

import SwiftUI
import CoreML
import Vision
import UIKit

struct ContentView: View {
    @State var segmentedChoice = 0
    
    @State var searchMode = false
    
    @State private var searchText = ""
    
    var body: some View{
        NavigationStack{
            Divider()
            
            if !searchMode {
                Text("")
                    .navigationTitle("Exercise")
                
                Picker("",selection: $segmentedChoice){
                    Text("All").tag(0)
                    Text("Favorites").tag(1)
                }.padding().pickerStyle(SegmentedPickerStyle())
                if (segmentedChoice == 0){
                    PageOne()
                    Spacer()
                }
                if (segmentedChoice == 1){
                    Favorites()
                    Spacer()
                }
            }else{
                PageOne()
                Spacer()
            }
            
        }.searchable(text: $searchText)
            .onChange(of: searchText) { searchText in
                
                if !searchText.isEmpty {
                    searchMode = true
                } else {
                    searchMode = false
                }
            }
        
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
        
    }
}


