//
//  PhotoEleaboration.swift
//  APPOSTURE
//
//  Created by Domenico De Litteris on 18/12/22.
//

import SwiftUI

struct PhotoEleaboration: View {
    var body: some View {
        Text("Hello World!")
    }
}

struct PhotoEleaboration_Previews: PreviewProvider {
    static var previews: some View {
        PhotoEleaboration()
    }
}
