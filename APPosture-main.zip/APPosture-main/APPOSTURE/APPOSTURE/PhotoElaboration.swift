//
//  PhotoElaboration.swift
//  APPOSTURE
//
//  Created by Christian Porritiello on 18/12/22.
//

import SwiftUI
import Vision
import Foundation

struct PhotoElaboration: View {
    
    
    //@State var iuMage = UIImage(named: "squat")
    
  
    
    var body: some View {
        Text("ciao")
        
        /*GeometryReader{ geometry in
         let request = try? VNDetectHumanBodyPoseRequest(completionHandler: {
         request, error in
         let observations = request.results as?  [VNHumanBodyPoseObservation]
         processObservation(observations![0], geometry)
         })
         let handler = try? VNImageRequestHandler(cgImage: iuMage!.cgImage!)
         try? handler!.perform([request!])
         
         //            Rectangle()
         //                .frame(width: geometry.size.width, height: geometry.size.height)
         
         }
         
         
         
         }
         
         func processObservation(_ observation: VNHumanBodyPoseObservation, _ geometry: GeometryProxy) {
         
         // Retrieve all torso points.
         guard let recognizedPoints =
         try? observation.recognizedPoints(.torso) else { return }
         
         // Torso joint names in a clockwise ordering.
         let torsoJointNames: [VNHumanBodyPoseObservation.JointName] = [
         .neck,
         .root
         
         ]
         
         print(geometry.size)
         
         // Retrieve the CGPoints containing the normalized X and Y coordinates.
         let imagePoints: [CGPoint] = torsoJointNames.compactMap {
         guard let point = recognizedPoints[$0], point.confidence > 0 else { return CGPoint(x: 0, y: 0)}
         
         // Translate the point from normalized-coordinates to image coordinates.
         return VNImagePointForNormalizedPoint(point.location,
         //                                                  Int(geometry.size.width),
         //                                                  Int(geometry.size.height))
         Int(iuMage!.size.width),
         Int(iuMage!.size.height))
         }
         
         // Draw the points onscreen.
         iuMage = draw(points: imagePoints)
         }
         
         func draw(points: [CGPoint]) -> UIImage? {
         
         UIGraphicsBeginImageContext(iuMage!.size)
         iuMage?.draw(at: CGPoint.zero)
         let context = UIGraphicsGetCurrentContext()!
         context.translateBy(x: 0, y: iuMage!.size.height)
         context.scaleBy(x: 1.0, y: -1.0)
         
         for point in points{
         context.setStrokeColor(UIColor.green.cgColor)
         context.setAlpha(1)
         context.setLineWidth(5.0)
         context.addEllipse(in: CGRect(x: point.x, y:  point.y, width: 50, height: 50))
         context.drawPath(using: .stroke)
         
         }
         let iMage = UIGraphicsGetImageFromCurrentImageContext()
         UIGraphicsEndImageContext()
         
         return iMage
         */
        
    }
}
    
////    func getImage(_ uiImage: UIImage){
//        iuMage = uiImage
//    }
//




struct PhotoElaboration_Previews: PreviewProvider {
    static var previews: some View {
        PhotoElaboration()
    }
}
