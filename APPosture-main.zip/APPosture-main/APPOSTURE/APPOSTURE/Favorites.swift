//
//  Favorites.swift
//  APPOSTURE
//
//  Created by Domenico De Litteris on 18/12/22.
//

import Foundation
import SwiftUI
import Vision
import UIKit

struct Favorites: View {
    
    @State var segmentedChoice = 0
    @State var isFavorite = false
    
    var body: some View{
        ZStack{
            NavigationLink(destination: SquatInstructions()){
                Image("squat")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(30)
                    .padding(10)
                    .padding(.top,11)
                    .frame(alignment: .center)
                Button(action: {
                    
                    self.isFavorite.toggle()
                }) {
                    Image(systemName: "star.fill")
                        .foregroundColor( .yellow)
                        .font(.system(size: 24))
                    
                }
            }
            
            
            Button(action: {
                
                let hostingController = UIHostingController(rootView: CameraView())
                hostingController.modalPresentationStyle = .fullScreen
                UIApplication.shared.windows.first?.rootViewController?.present(hostingController, animated: true)}) {
                    
                }
        }
        
    }
}
