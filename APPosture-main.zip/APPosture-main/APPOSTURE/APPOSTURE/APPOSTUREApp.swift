//
//  APPOSTUREApp.swift
//  APPOSTURE
//
//  Created by Domenico De Litteris on 13/12/22.
//

import SwiftUI

@main
struct APPOSTUREApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
