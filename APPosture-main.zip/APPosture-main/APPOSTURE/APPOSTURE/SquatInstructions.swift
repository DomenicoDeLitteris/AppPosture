//
//  SquatInstructions.swift
//  APPOSTURE
//
//  Created by Domenico De Litteris on 18/12/22.
//

import UIKit
import SwiftUI
import PhotosUI
import Foundation
import Vision

public var modalImage = UIImage()

struct SquatInstructions: View {
    
    @State private var image = UIImage()
    
    @State private var selectedImage: PhotosPickerItem? = nil
    
    @State private var selectedImageData: Data? = nil
    
    
    
    var body: some View {
        VStack {
            NavigationView {
                
                
                VStack(alignment: .leading) {
                    
                    ZStack {
                        Image("squat-instructions")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(30)
                            .padding(10)
                            .frame(alignment: .center)
                        
                        PhotosPicker(selection: $selectedImage, label: {ZStack{
                            RoundedRectangle(cornerRadius: 25)
                                .frame(width: 150,height: 55)
                            Text("Pick image")
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }})
                        .onChange(of: selectedImage){newItem in
                            Task{
                                if let data = try? await newItem?.loadTransferable(type: Data.self){
                                    selectedImageData = data
                                }
                            }
                            
                        }
                        /*if let selectedImageData,
                            let modalImage = UIImage(data:  selectedImageData) {
                         Text("valor")
                            
                          /*  Image(uiImage: modalImage)
                                .resizable()
                                .scaledToFill()
                                .clipped()
                            
                            */
                        }*/
                    }
                    
                    Text("Perform the squat as follows:")
                    
                        .font(.system(size: 25))
                    
                    
                    Text("1. Start standing with your feet shoulder-width apart.").font(.system(size: 20))
                    Text("2.Lower your body down as if you are sitting on a chair.").font(.system(size: 20))
                    Text("3.Keep your back straight and your buttocks back.").font(.system(size: 20))
                    Text("4. Push back up and return to the starting position.").font(.system(size: 20))
                    
                    Spacer()
                    
                    if let selectedImageData,
                        let modalImage = UIImage(data:  selectedImageData) {
                     Text("valor")
                        
                        NavigationLink( destination: ModalView(), label: {
                            ZStack{
                                RoundedRectangle(cornerRadius: 25)
                                    .frame(width: 150,height: 55)
                                Text("start")
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            }.frame(alignment: .center)
                            //                                DA VEDERE L'ALLINEAMENTO
                            
                        })
                    }
                    else
                    {
                        Text("")
                        //                        bottone spento da aggiungere
                    }
                    Spacer()
                }.navigationBarTitle("Doing a Squat")
                
                
                
                    .padding()
            }
        }
        
    }
    
    
    struct ContentVi: PreviewProvider {
        static var previews: some View {
            SquatInstructions()
            
        }
    }
    struct ModalView: View {
        @Environment(\.presentationMode) var presentationMode
        var segmentedChoice = 0
        
        @State var isFavorite = false
        
        @State var iuMage: UIImage? = modalImage as UIImage
        
        var body: some View{
            
            ZStack{
                
                GeometryReader { geometry in
                    NavigationLink(destination: SquatInstructions()){
                        Image(uiImage: modalImage)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(30)
                            .padding()
                            .frame(alignment: .center)
                        
                       
                        
                    }
                    
                    
                    Button(action: {
                        
                        let request = try? VNDetectHumanBodyPoseRequest(completionHandler: {
                            request, error in
                            let observations = request.results as?  [VNHumanBodyPoseObservation]
                            processObservation(observations![0], geometry)
                        })
                        let handler = try? VNImageRequestHandler(cgImage: modalImage.cgImage!)
                        try? handler!.perform([request!])
                        
                        
                        
                        
                        self.isFavorite.toggle()
                    }) { ZStack{
                        RoundedRectangle(cornerRadius: 25)
                            .frame(width: 150,height: 55)
                        Text("Analayze")
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }.frame(alignment: .center)
                       
                    }
                    .padding(.top,190)
                    .padding(.bottom,0)
                    .padding(.leading,300)
                    .frame(alignment: .bottomTrailing)
    //            Rectangle()
    //                .frame(width: geometry.size.width, height: geometry.size.height)
                    
                }
                
               
            }
        }
        
        func processObservation(_ observation: VNHumanBodyPoseObservation, _ geometry: GeometryProxy) {
            
            // Retrieve all torso points.
            guard let recognizedPoints =
                    try? observation.recognizedPoints(.torso) else { return }
            
            // Torso joint names in a clockwise ordering.
            let torsoJointNames: [VNHumanBodyPoseObservation.JointName] = [
                .neck,
                .root
                
            ]
            
            print(geometry.size)
            
            // Retrieve the CGPoints containing the normalized X and Y coordinates.
            let imagePoints: [CGPoint] = torsoJointNames.compactMap {
                guard let point = recognizedPoints[$0], point.confidence > 0 else { return CGPoint(x: 0, y: 0)}
                
                // Translate the point from normalized-coordinates to image coordinates.
                return VNImagePointForNormalizedPoint(point.location,
    //                                                  Int(geometry.size.width),
    //                                                  Int(geometry.size.height))
                                                      Int(iuMage!.size.width),
                                                      Int(iuMage!.size.height))
            }
            
            // Draw the points onscreen.
            iuMage = draw(points: imagePoints)
        }
        
        func draw(points: [CGPoint]) -> UIImage? {
            
            UIGraphicsBeginImageContext(iuMage!.size)
            iuMage?.draw(at: CGPoint.zero)
            let context = UIGraphicsGetCurrentContext()!
            context.translateBy(x: 0, y: iuMage!.size.height)
            context.scaleBy(x: 1.0, y: -1.0)
            
            for point in points{
                context.setStrokeColor(UIColor.green.cgColor)
                context.setAlpha(1)
                context.setLineWidth(5.0)
                context.addEllipse(in: CGRect(x: point.x, y:  point.y, width: 50, height: 50))
                context.drawPath(using: .stroke)
                
            }
            let iMage = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            
            return iMage
            
        }
    }
}
/*GeometryReader{ geometry in
 let request = try? VNDetectHumanBodyPoseRequest(completionHandler: {
 request, error in
 let observations = request.results as?  [VNHumanBodyPoseObservation]
 processObservation(observations![0], geometry)
 })
 let handler = try? VNImageRequestHandler(cgImage: iuMage!.cgImage!)
 try? handler!.perform([request!])
 
 //            Rectangle()
 //                .frame(width: geometry.size.width, height: geometry.size.height)
 
 }
 
 
 
 }
 
 func processObservation(_ observation: VNHumanBodyPoseObservation, _ geometry: GeometryProxy) {
 
 // Retrieve all torso points.
 guard let recognizedPoints =
 try? observation.recognizedPoints(.torso) else { return }
 
 // Torso joint names in a clockwise ordering.
 let torsoJointNames: [VNHumanBodyPoseObservation.JointName] = [
 .neck,
 .root
 
 ]
 
 print(geometry.size)
 
 // Retrieve the CGPoints containing the normalized X and Y coordinates.
 let imagePoints: [CGPoint] = torsoJointNames.compactMap {
 guard let point = recognizedPoints[$0], point.confidence > 0 else { return CGPoint(x: 0, y: 0)}
 
 // Translate the point from normalized-coordinates to image coordinates.
 return VNImagePointForNormalizedPoint(point.location,
 //                                                  Int(geometry.size.width),
 //                                                  Int(geometry.size.height))
 Int(iuMage!.size.width),
 Int(iuMage!.size.height))
 }
 
 // Draw the points onscreen.
 iuMage = draw(points: imagePoints)
 }
 
 func draw(points: [CGPoint]) -> UIImage? {
 
 UIGraphicsBeginImageContext(iuMage!.size)
 iuMage?.draw(at: CGPoint.zero)
 let context = UIGraphicsGetCurrentContext()!
 context.translateBy(x: 0, y: iuMage!.size.height)
 context.scaleBy(x: 1.0, y: -1.0)
 
 for point in points{
 context.setStrokeColor(UIColor.green.cgColor)
 context.setAlpha(1)
 context.setLineWidth(5.0)
 context.addEllipse(in: CGRect(x: point.x, y:  point.y, width: 50, height: 50))
 context.drawPath(using: .stroke)
 
 }
 let iMage = UIGraphicsGetImageFromCurrentImageContext()
 UIGraphicsEndImageContext()
 
 return iMage
 */




